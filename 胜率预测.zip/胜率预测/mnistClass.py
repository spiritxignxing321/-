#***************************一些必要的包的调用********************************
from make_cards import *
import torch.nn.functional as F
import torch
import torch 
import torch.nn as nn
from torch.autograd import Variable
import torchvision.models as models
from torchvision import transforms, utils
from torch.utils.data import Dataset, DataLoader
from PIL import Image
import numpy as np
from collections import Counter
import torch.optim as optim
import os

   

class MyDataset(Dataset): 
                             #创建自己的类： MyDataset,这个类是继承的torch.utils.data.Dataset
        #**********************************  #使用__init__()初始化一些需要传入的参数及数据集的调用**********************
    def __init__(self,path):
                              
        super(MyDataset,self).__init__()
                               #对继承自父类的属性进行初始化
                               
                               
        self.data, self.label = load_from_file(path)
        print('data_suit:',len(self.data) ,len(self.label));
        

        bbb = np.sum(self.label>0.5).astype(int)
        print('zero:',bbb)  
                                  
            #*************************** #使用__getitem__()对数据进行预处理并返回想要的信息**********************
    def __getitem__(self, index):#这个方法是必须要有的，用于按照索引读取每个元素的具体内容
        #self.data = self.data.astype(np.float32)

        return torch.from_numpy(self.data[index].astype(np.float32)).view(1,17,15),self.label[index]
                          #return回哪些内容，那么我们在训练时循环读取每个batch时，就能获得哪些内容
             #**********************************  #使用__len__()初始化一些需要传入的参数及数据集的调用**********************
    def __len__(self):
            #这个函数也必须要写，它返回的是数据集的长度，也就是多少张图片，要和loader的长度作区分
        #print(len(self.data));
        return len(self.data)
     
    #统计各标签出现的次数，按照0~299顺序分布，没有出现过的置为1 
    def count_labels(self):  
        count_l=np.ones(300,dtype = np.int32)
        for i in np.unique(self.label):
            count_l[i] = np.sum(self.label==i)  # 对照unique数组，依次统计每个元素出现的次数
        return count_l


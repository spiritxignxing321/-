import torch
import torch.nn as nn
from torchvision.datasets import CIFAR10
from torch.utils.data import sampler
from torchvision import transforms
from torch.utils.data import DataLoader,Dataset
from torch.optim import Adam
import mnistClass
import numpy as np
import os
import shutil
 
"""
torch.nn是专门为神经网络设计的模块化接口。nn构建于autograd之上，可以用来定义和运行神经网络。
nn.Module是nn中十分重要的类,包含网络各层的定义及forward方法。
定义自已的网络：
    需要继承nn.Module类，并实现forward方法。
    一般把网络中具有可学习参数的层放在构造函数__init__()中，
    不具有可学习参数的层(如ReLU)可放在构造函数中，也可不放在构造函数中(而在forward中使用nn.functional来代替)。    
    只要在nn.Module的子类中定义了forward函数，backward函数就会被自动实现(利用Autograd)。
注：Pytorch基于nn.Module构建的模型中，只支持mini-batch的Variable输入方式，
    比如，只有一张输入图片，也需要变成 N x C x H x W 的形式：    
    input_image = torch.FloatTensor(1, 28, 28)   
    input_image = input_image.unsqueeze(0)   # 1 x 1 x 28 x 28
"""
class Unit(nn.Module):#以上解释了这里为什么必须写出继承类nn.Module
    def __init__(self,inc,ouc):
        super(Unit,self).__init__()
        self.unit_net = nn.Sequential(nn.Conv2d(inc,ouc,kernel_size=3,padding=1),
                      nn.BatchNorm2d(ouc),
                      nn.ReLU())
    def forward(self, x):
        return self.unit_net(x)
 
class Net(nn.Module):
    def __init__(self):
        super(Net,self).__init__()
        self.net = nn.Sequential(Unit(1,6),    #17*15*6


                                 nn.MaxPool2d(2,padding=1),  #9*8*6

                                 Unit(6,16), #9*8*16

                                 nn.MaxPool2d(2,padding=1),   #5*5*16

                                 )
        self.fc1 = nn.Linear(400,120)
        self.fc2 = nn.Linear(120,84)
        self.fc3 = nn.Linear(84,2)

    def forward(self,x):
        x=self.net(x)
        x=x.view(-1,400)   #400=5*5*16
        x=self.fc1(x)
        x=self.fc2(x)
        x=self.fc3(x)
        return x
 
#加载测试集与训练集
full_dataset = mnistClass.MyDataset("data/yucesample");  #数据全集
#print(len(full_dataset));
train_size = int(0.8 * len(full_dataset))     #训练集占%80
test_size = len(full_dataset) - train_size    #测试集占%20
train_set, test_set = torch.utils.data.random_split(full_dataset, [train_size, test_size])
print('train_size:',train_size);
print('test_size:',test_size);

#count_l=np.ones(300,dtype = np.int32)
#train_labels =np.array([label for _,label in train_set])
#for i in np.unique(train_labels):
#    count_l[i] = np.sum(train_labels==i)  # 对照unique数组，依次统计每个元素出现的次数

#print(count_l)
#weight = 1./ count_l           #根据标签出现的次数计算权值，次数越多，采样权值越大
#samples_weight = np.array([weight[t] for t in train_labels])
#samples_weight = torch.from_numpy(samples_weight)
#samples_weight = samples_weight.double()
#print(len(samples_weight))
#权重采样器
#sampler = sampler.WeightedRandomSampler(samples_weight, len(samples_weight))

train_dataloader = DataLoader(train_set,batch_size=512,shuffle=True)
test_dataloader = DataLoader(test_set,batch_size=512,shuffle=True)


#参数存放路径

param_path = r'./param/mnist_cnn.pkl'
tmp_param_path = r'./param/mnist_cnn_temp.pkl'
 
CUDA = torch.cuda.is_available()
print('CUDA:',CUDA)
module = Net()
if CUDA:
    module.cuda()
optimizer = Adam(module.parameters(),lr=0.0005,weight_decay=0.0001)
loss_f = nn.CrossEntropyLoss()#分类用交叉熵
 
'创建一个学习率调整函数，每30个周期将学习率除以10'
def adjust_lr_rate(epoch):
    lr = 0.01
    if epoch>120:
        lr = lr / 1000000
    elif epoch>100:
        lr = lr / 100000
    elif epoch>80:
        lr = lr / 10000
    elif epoch>60:
        lr = lr / 1000
    elif epoch>40:
        lr = lr / 100
    elif epoch>20:
        lr = lr / 10
    for param_group in optimizer.param_groups:
        param_group['lr'] = lr
 
def test():#测试集1万张
    test_acc = 0
    module.eval()
    for j,(imgs, labels) in enumerate(test_dataloader):#每次处理512张
        if CUDA:
            imgs = imgs.cuda()
            labels = labels.cuda()
        outs = module(imgs)
        #训练求loss是为了做权重更新，测试里不需要
        _, prediction = torch.max(outs, 1)
        test_acc += torch.sum(prediction == labels)
    test_acc = test_acc.cpu().item() / test_size
    return test_acc
 
def train(num_epoch):#训练集5万张
    #if os.path.exists(param_path):
        #module.load_state_dict(torch.load(param_path))
    #loss_count=[]
    for epoch in range(num_epoch):
        train_loss = 0
        train_acc = 0
        module.train()
        for i, (imgs, labels) in enumerate(train_dataloader):#每次处理512张
            # print('labels:',labels)#每个标签对应一个0-9的数字
            #print(type(labels));
            #print(type(imgs));
            #print(i)
            #print('imgs:',imgs.shape)#每个标签对应一个0-9的数字
            #print('labels:',labels)#每个标签对应一个0-9的数字
            
            if CUDA:
                imgs = imgs.cuda()
                labels = labels.cuda()
            outs = module(imgs)
            #print('outs:',outs)
            #print(outs.shape)
            loss = loss_f(outs, labels.long())
 
            optimizer.zero_grad()  #使用优化器优化损失
            loss.backward()     # 误差反向传播，计算参数更新值
            optimizer.step()    # 将参数更新值施加到net的parmeters上
            
            train_loss += loss.cpu().item() * imgs.size(0)#imgs.size(0)批次
            '分类问题，常用torch.max(outs,1)得到索引来表示类别'
            _, prediction = torch.max(outs,1)#prediction对应每行最大值所在位置的索引值，即0-9
            #print('prediction:',prediction)
            pp = torch.sum(prediction == labels)
            train_acc += pp
            
            if i%5 == 0:
                #loss_count.append(loss)
                xfj=520
                #print('{}:\t'.format(i), loss.item(),pp)
            # print(train_acc.cpu().item())
 
        #adjust_lr_rate(epoch)
        train_loss = train_loss / train_size
        train_acc = train_acc.cpu().item() / train_size #此处求概率必须用item()把数值取出，否则求出的不是小数
 
        '每训练完一个epoch，用测试集做一遍评估'
        test_acc = test()
        best_acc = 0
        if test_acc > best_acc:
            best_acc = test_acc
            torch.save(module.state_dict(),tmp_param_path)
            if os.path.exists(tmp_param_path):
                shutil.copyfile(tmp_param_path, param_path)#防权重损坏
            
        print('Epoch:',epoch,'Train_Loss:',train_loss,'Train_Acc:',train_acc,'Test_Acc:',test_acc)
 
train(100)

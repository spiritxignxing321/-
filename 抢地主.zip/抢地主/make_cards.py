# -*-coding:utf-8-*-

# (1) BUILD CARDS THAT ARE POSSIBLE HANDOUT FOR DOU DI ZHU
# (2) BUILD SAMPLES FROM EXCEL DATA

# YISONG WANG
# 2019.09.25

import numpy as np
from pandas import DataFrame
import itertools
import xlrd
import argparse

'''
出牌类型    可能出现的个数    Label表示的位置
PASS    1    0
单牌        15    1-15
对子        13    16-28
3连对    10    29-38
4连对    9    39-47
5连对    8    48-55
6连对    7    56-62
7连对    6    63-68
8连对    5    69-73
9连对    4    74-77
10连对    3    78-80
5连牌    8    81-88
6连牌    7    89-95
7连牌    6    96-101
8连牌    5    102-106
9连牌    4    107-110
10连牌    3    111-113
11连牌    2    114-115
12连牌    1    116
炸弹（4张牌）    13    117-129
王炸        1    130
3个牌单出        13    131-143
飞机不带牌（2连）    11    144-154
飞机不带牌（3连）    10    155-164
飞机不带牌（4连）    9    165-173
飞机不带牌（5连）    8    174-181
飞机不带牌（6连）    7    182-188
（以下为带牌情况）        
3带1        13    189-201
飞机带牌（2连）    11    202-212
飞机带牌（3连）    10    213-222
飞机带牌（4连）    9    223-231
飞机带牌（5连）    8    232-239
4带2（两单牌）    13    240-252
4带2（对子）        13    253-265

3-10用数字3-10表示，J,Q,K,A,2,小王,大王分别用11,12,13,14,15,16,17表示
'''



def cards_str_list(cards_str):  # '5,5,13,13,13' to ordered list [ 5, 5, 13, 13, 13 ]
    if cards_str == '':
        return list()
    else:
        rl = list()
        for x in str(cards_str).split(','):
            if x == '':
                continue
            if float(x) > 16:
                rl.append(int(float(x)) - 1)
            else:
                rl.append(int(float(x)))

        return sorted(rl)



def build_sample(excl_file='data-test.xlsx', to_file_head='sample'):

    # (1) read excl data from excl_file
    workbook = xlrd.open_workbook(filename=excl_file)
    booksheet = workbook.sheet_by_index(0)
    n_samples = 0

    # Data = np.zeros((1)) # the list of samples, 18*6 for one sample
    # Label = list() # the key of the action for the corresponding sample in Data

    # (2) build the sample
    i = 1
    n_samples = 0
    while (i < booksheet.nrows - 2):
        print(i)
        pid1 = int(booksheet.cell_value(i, 3))  # 玩家1身份
        pid2 = int(booksheet.cell_value(i, 6))  # 玩家2身份
        pid3 = int(booksheet.cell_value(i, 9))  # 玩家3身份
        if pid1 == 1:          #获取地主手牌
            dizhu_cards = cards_str_list(booksheet.cell_value(i, 5))
        elif pid2 == 1:
            dizhu_cards = cards_str_list(booksheet.cell_value(i, 7))
        else:
            dizhu_cards = cards_str_list(booksheet.cell_value(i, 10))

        three_cards = cards_str_list(booksheet.cell_value(i, 11))
        for m in three_cards:
            dizhu_cards.remove(m)

        #print(dizhu_cards)
        
        if len(dizhu_cards) != 17:  #检验地主手牌是否17张
            i+=1
            continue
        
        cols = np.zeros((17, 15))
     
        j=0
        for x in dizhu_cards:
            cols[j,x-3]=1

        if n_samples == 0:
            Data = cols.copy().reshape((1, 17, 15))
            Label = np.array([int(booksheet.cell_value(i, 16))])
        else:
            try:
                Label = np.append(Label, [int(booksheet.cell_value(i, 16))], 0)
                Data = np.append(Data, cols.reshape((1, 17, 15)), 0)
            except TypeError as reason:
                print("line %d, the played cards: " % i + str(action_cards))
        # for the next sample
        n_samples += 1
        i+=1
      

    # n_data = np.asarray(Data).reshape((16,6, len(Data)/96))
    # n_label = np.asarray(Label)

    if not to_file_head == "":

        Data.tofile(to_file_head + "_data")
        Label.tofile(to_file_head + "_label")

    return (Data, Label)


def load_from_file(file_name='sample'):
    # load the data and label from file
    # file_name + '_data'
    # file_name + '_label'
    # repectively
    D = np.fromfile(file_name + '_data')
    L = np.fromfile(file_name + '_label', dtype='int')
    # 构造onehot
    tL = np.zeros((int(D.size / 255), 4), dtype=np.int)
    for x in range(int(D.size / 255)):
        tL[x][L[x]] = 1
    #L = tL
    return (D.reshape((int(D.size / 255), 255)), L)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='Build Dou Di Zhu samples')
    parser.add_argument("file_CNF", help="theory file")
    parser.add_argument("file_M", help="model file")
    # parser.add_argument("-file_S", type = str, help = "S file", required=False) # part of atoms in M

    build_sample("data/fandy_qdzmatch.xlsx", "qdzsample")
